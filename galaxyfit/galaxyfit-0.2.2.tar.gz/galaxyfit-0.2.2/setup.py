from distutils.core import setup,Extension

intmodule = Extension('galaxyfit/galaxyintegrate',sources=['galaxyfit/galaxyintegrate.cpp'],depends=['DEIntegrator.h'])

setup(
    name='galaxyfit',
    version='0.2.2',
    author='Andrew Schechtman-Rook',
    author_email='rook166@gmail.com',
    packages=['galaxyfit'],
    license='LICENSE.txt',
    description='Galaxy Fitting',
    long_description=open('README.txt').read(),
    ext_modules = [intmodule],
)
