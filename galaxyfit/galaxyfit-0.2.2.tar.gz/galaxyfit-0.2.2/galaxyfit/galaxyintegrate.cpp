#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <stdio.h>
#include <fstream>
#include <cmath>
#include <string>
#include <vector>
#include <cassert>
#include <sstream>
#include <time.h>
//#include "/usr/users/andrew/libraries/headers/functions.h"
#include "DEIntegrator.h"
//#include "fitsio.h"
//#include "omp.h"
using namespace std;

const double pi = 3.14159265;

class ring_int
{
public:
    ring_int(double r_inp, double z_inp, double sini_inp, double cosi_inp, double rzero_inp, double sigzero_inp, double hz_inp, double izero_inp)
	{
	    r_square = r_inp*r_inp;
	    sini = sini_inp;
	    cosi = cosi_inp;
	    z_sini = z_inp*sini;
	    rzero = rzero_inp;
	    //sigzero = sigzero_inp;
	    sigzero_square = sigzero_inp*sigzero_inp;
	    hz = hz_inp;
	    izero = izero_inp;
	}
    double operator()(double t) const
	{
	    // double total = 0;
	    // for(int i = 0; i < izero.size(); i++)
	    // {
	    // 	total += izero[i]*exp(-sqrt(r_square+pow(t*sini,2))/hr[i]-abs(z_sini-t*cosi)/hz[i]);
	    // 	//cout<<izero[i]<<"  "<<hr[i]<<"   "<<hz[i]<<endl;
	    // }
	    double rprime = sqrt(r_square+pow(t*sini,2));
	    return izero*exp(-pow(rprime-rzero,2)/(2*sigzero_square)-abs(z_sini-t*cosi)/hz);
	}
    void set_r_z(double newr, double newz)
	{
	    r_square = newr*newr;
	    z_sini = newz*sini;
	}
private:
    double r_square;
    double z_sini;
    double sini;
    double cosi;
    double rzero;
    double sigzero_square;
    double hz;
    double izero;
};

class multidisk
{
public:
    multidisk(double r_inp, double z_inp, double sini_inp, double cosi_inp, vector<double> hr_inp, vector<double> hz_inp, vector<double> izero_inp)
	{
	    r_square = r_inp*r_inp;
	    sini = sini_inp;
	    cosi = cosi_inp;
	    z_sini = z_inp*sini;
	    hr = hr_inp;
	    hz = hz_inp;
	    izero = izero_inp;
	    // for(int i = 0; i < muzero_inp.size(); i++)
	    // {
	    // 	izero.push_back(pow(10.,-muzero_inp[i]/2.5)/(2*hr[i]));//From SB to emissivity
	    // }
	    //cout<<muzero_inp.size()<<endl;
	}
    double operator()(double t) const
	{
	    double total = 0;
	    for(int i = 0; i < izero.size(); i++)
	    {
		total += izero[i]*exp(-sqrt(r_square+pow(t*sini,2))/hr[i]-abs(z_sini-t*cosi)/hz[i]);
		//cout<<izero[i]<<"  "<<hr[i]<<"   "<<hz[i]<<endl;
	    }
	    return total;
	}
    void set_r_z(double newr, double newz)
	{
	    r_square = newr*newr;
	    z_sini = newz*sini;
	}
private:
    double r_square;
    double z_sini;
    double sini;
    double cosi;
    vector<double> hr;
    vector<double> hz;
    vector<double> izero;
};

double computebulgei(double r,double z,double ab,double n, double bn, double re,double izero)
{
    double ie = izero/exp(bn);
    double deprojr = sqrt(r*r+z*z*ab*ab);
    //return izero*exp(-7.669*pow(deprojr/re,0.25));
    return ie*exp(-bn*(pow(deprojr/re,1./n)-1));
}


vector<vector<double> > computebounds_bothtruncations(double bound,double inclination, double r, double z, double innertrunc,double outertrunc)
{
    //Does not handle: innertrunc larger than outertrunc, very small inclinations, computing more than the first quadrant of the galaxy
    vector<vector<double> > truncbounds;
    double sini = sin(inclination*pi/180.);
    double critical_t_inner = sqrt(innertrunc*innertrunc-r*r)/sini;
    double critical_t_outer = sqrt(outertrunc*outertrunc-r*r)/sini;
    if(r > outertrunc)
    {
    	return truncbounds;//An empty array
    }
    if(bound <= critical_t_inner)
    {
	return truncbounds;//An empty array
    }
    double singularityposition = 0;
    if(inclination < 89.999)
    {
    	singularityposition = z*sin(inclination*pi/180.)/cos(inclination*pi/180);
    }

    if(bound > critical_t_outer)
    {
	bound = critical_t_outer;
    }
    if(r < innertrunc)
    {
	if(singularityposition > critical_t_inner && singularityposition < bound)//singularityposition can't be negative
	{
		vector<double> tempvector1(2,-bound);
		tempvector1[1] = -critical_t_inner;
		vector<double> tempvector2(2,critical_t_inner);
		tempvector2[1] = singularityposition;
		vector<double> tempvector3(2,singularityposition);
		tempvector3[1] = bound;
		truncbounds.push_back(tempvector1);
		truncbounds.push_back(tempvector2);
		truncbounds.push_back(tempvector3);
	}
	else
	{
		vector<double> tempvector1(2,-bound);
		tempvector1[1] = -critical_t_inner;
		vector<double> tempvector2(2,critical_t_inner);
		tempvector2[1] = bound;
		truncbounds.push_back(tempvector1);
		truncbounds.push_back(tempvector2);
	}
    }
    else
    {
	if(singularityposition < bound)
	{
		vector<double> tempvector1(2,-bound);
		tempvector1[1] = singularityposition;
		vector<double> tempvector2(2,singularityposition);
		tempvector2[1] = bound;
		truncbounds.push_back(tempvector1);
		truncbounds.push_back(tempvector2);
	}
	else
	{
	    vector<double> tempvector1(2,-bound);
	    tempvector1[1] = bound;
	    truncbounds.push_back(tempvector1);
	}
    }
    return truncbounds;
}

void cpp_integrategalaxy(void * imagev, double * rvals, double * zvals, int rlen, int zlen, double * izero_disk, double * hr, double * hz, double * innertruncr, double * outertruncr, int * numpertrunc, int numtruncs, double * izero_ring, double * rzero, double * sigzero, double * ringhz, int numrings, double * izero_bulge, double * re, double * ab, double * n, double * bn, int numbulges, double inclination, double bound, int numcores)
{
    // time_t start,end;
    // time(&start);
    double * image = (double *) imagev;

    double sini = sin(inclination*pi/180.);
    double cosi = cos(inclination*pi/180.);

    //First, make 2D vectors holding the disk data:
    vector<vector<double> > izero_diskvector;
    vector<vector<double> > hr_diskvector;
    vector<vector<double> > hz_diskvector;
    int count = 0;
    for(int i = 0; i < numtruncs; i++)
    {
	vector<double> tempizero;
	vector<double> temphr;
	vector<double> temphz;
	for(int j = 0; j < numpertrunc[i]; j++)
	{
	    tempizero.push_back(izero_disk[count]);
	    temphr.push_back(hr[count]);
	    temphz.push_back(hz[count]);
	    count++;
	}
	izero_diskvector.push_back(tempizero);
	hr_diskvector.push_back(temphr);
	hz_diskvector.push_back(temphz);

    }
    
    //Then iterate through each pixel:
    // int numpixels = rlen*zlen;
    // cout<<"Number of pixels = "<<numpixels<<endl;
//    omp_set_num_threads(numcores);
//#pragma omp parallel for shared(bound,inclination,rvals,zvals,innertruncr,outertruncr,sini,cosi,hr_diskvector,hz_diskvector,izero_diskvector,numrings,rzero,sigzero,ringhz,izero_ring,numbulges,image,ab,n,bn,re,izero_bulge)
    for(int r = 0; r < rlen; r++)
    {
	for(int z = 0; z < zlen; z++)
	{
	    image[r*zlen+z] = 0;
	    for(int i = 0; i < izero_diskvector.size(); i++)
	    {
		vector<vector<double> > integrationbounds = computebounds_bothtruncations(bound,inclination,abs(rvals[r]),abs(zvals[z]),innertruncr[i], outertruncr[i]);
		multidisk disks(abs(rvals[r]),abs(zvals[z]),sini,cosi,hr_diskvector[i],hz_diskvector[i],izero_diskvector[i]);
		for(int j = 0; j < integrationbounds.size(); j++)
		{
		    image[r*zlen+z] += DEIntegrator<multidisk>::Integrate(disks,integrationbounds[j][0],integrationbounds[j][1],1e-14);
		}
	    }
	    for(int i = 0; i < numrings; i++)
	    {
		ring_int ring(abs(rvals[r]),abs(zvals[z]),sini,cosi,rzero[i],sigzero[i],ringhz[i],izero_ring[i]);
		double discontinuity = abs(zvals[z])*sini/cosi;
		double temptotal = 0;
		if(discontinuity <= -bound || discontinuity >= bound)
		{
		    temptotal = DEIntegrator<ring_int>::Integrate(ring,-bound,bound,1e-14);
		}
		else
		{
		    temptotal = DEIntegrator<ring_int>::Integrate(ring,-bound,discontinuity,1e-14);
		    temptotal += DEIntegrator<ring_int>::Integrate(ring,discontinuity,bound,1e-14);
		}
		// if(discontinuity >= bound || discontinuity < 1e-5)
		// {
		//     temptotal = DEIntegrator<ring_int>::Integrate(ring,0,bound,1e-14);
		// }
		// else
		// {
		//     cout<<abs(zvals[z])<<"  "<<sini<<"  "<<cosi<<"  "<<discontinuity<<endl;
		//     temptotal = DEIntegrator<ring_int>::Integrate(ring,0,discontinuity,1e-14);
		//     temptotal += DEIntegrator<ring_int>::Integrate(ring,discontinuity,bound,1e-14);
		// }
		//double temptotal = DEIntegrator<ring_int>::Integrate(ring,0,bound,1e-14);
		image[r*zlen+z] += temptotal;
		//image[r*zlen+z] += 2.*DEIntegrator<ring_int>::Integrate(ring,0,bound,1e-14);
	    }
	    
	    for(int i = 0; i < numbulges; i++)
	    {
		image[r*zlen+z] += computebulgei(abs(rvals[r]),abs(zvals[z]),ab[i],n[i],bn[i],re[i],izero_bulge[i]);
	    }
	}
    }

    // time(&end);
    // cout<<"Time = "<<difftime(end,start)<<" (s)"<<endl;
    // cout<<"Time per integration = "<<((double) difftime(end,start))/((double) numpixels)<<endl;
    //Image array is returned automatically (implicitly passed by reference, apparently)
}

void cpp_testdisk(double * rvalskpc, double * zvalskpc, int rvalslength, int zvalslength, double hr, double hz, double izero, void * outimagev)
{
    double * outimage = (double *) outimagev;
    for(int r = 0; r < rvalslength; r++)
    {
	for(int z = 0; z < zvalslength; z++)
	{
	    //outimage[r*zvalslength + z] = ((double) r*z)*1.3;
	    outimage[r*zvalslength + z] = izero*exp(-abs(rvalskpc[r])/hr-abs(zvalskpc[z])/hz);
	}
    }
}

void cpp_testmultidisk(double * izero, double * hr, double * hz, int numcomponents, double * innertrunc, double * outertrunc, int * numpertrunc, int numtruncs)
{
    int count = 0;
    for(int i = 0; i < numtruncs; i++)
    {
	cout<<innertrunc[i]<<"  "<<outertrunc[i]<<"  "<<numpertrunc[i]<<endl;
	for(int j = 0; j < numpertrunc[i]; j++)
	{
	    cout<<"  "<<izero[count]<<"  "<<hr[count]<<"  "<<hz[count]<<endl;
	    count++;
	}
    }

}

void cpp_test(int * testint, int len)
{
    for(int i = 0; i < len; i++)
    {
	cout<<testint[i]<<endl;
    }
}

extern "C"
{
    void testdisk(double * rvalskpc, double * zvalskpc, int rvalslength, int zvalslength, double hr, double hz, double izero, void * outimagev){cpp_testdisk(rvalskpc,zvalskpc,rvalslength,zvalslength,hr,hz,izero,outimagev);}
    void testmultidisk(double * izero, double * hr, double * hz, int numcomponents, double * innertrunc, double * outertrunc, int * numpertrunc, int numtruncs){cpp_testmultidisk(izero,hr,hz,numcomponents,innertrunc,outertrunc,numpertrunc,numtruncs);}
    void test(int *testint, int len){cpp_test(testint,len);}
    void integrategalaxy(void * imagev, double * rvals, double * zvals, int rlen, int zlen, double * izero_disk, double * hr, double * hz, double * innertruncr, double * outertruncr, int * numpertrunc, int numtruncs, double * izero_ring, double * rzero, double * sigzero, double * ringhz, int numrings, double * izero_bulge, double * re, double * ab, double * n, double * bn, int numbulges, double inclination, double bound, int numcores){cpp_integrategalaxy(imagev,rvals,zvals,rlen,zlen,izero_disk,hr,hz,innertruncr,outertruncr,numpertrunc,numtruncs,izero_ring,rzero,sigzero,ringhz,numrings,izero_bulge,re,ab,n,bn,numbulges,inclination,bound,numcores);}
}
