import numpy as np
import math
import os
import sys
import astropy.io.fits as pyfits
import astropy.wcs as pywcs
# import astropy.io.fits as pyfits
# import astropy.wcs as pywcs
import galfit_modelclass as modelclass
import galfit_setupmodel as setupmodel
import ConfigParser
##################################################################
#This file contains functions for reading in an input file and setting up a model
#Modification History:
#Date                  User                Notes
#6/7/13               ASR                 Created
#6/10/13              ASR                 Wrote process_cfg_param and readcfg
#6/11/13              ASR                 Wrote loadimgs, finished readcfg
##################################################################
#Print out a numpy array to a fits file, overwriting if necessary:
def writefits(image,filename,header=None):
    hdu = pyfits.PrimaryHDU(data=image,header=header)
    if os.path.isfile(filename):
        os.remove(filename)
    hdu.writeto(filename)
   

def getrzs(cfgfile):   
    config = ConfigParser.ConfigParser()
    config.read(cfgfile)
    imagename = None
    try:
        imagename = setupmodel.process_cfg_param(config,'data','image',str,False)
        #print imagename
        centerra_deg = setupmodel.process_cfg_param(config,'data','center_RA',float,False)
        #print centerra_deg
        centerdec_deg = setupmodel.process_cfg_param(config,'data','center_Dec',float,False)
        #print centerdec_deg
        distmpc = setupmodel.process_cfg_param(config,'constants','distance',float,False)
        #print distmpc
        seeing = setupmodel.process_cfg_param(config,'constants','seeing',float,False)
        #print seeing
        samplerate = setupmodel.process_cfg_param(config,'constants','samplerate',int,False)
        #print samplerate
    except:
        print "modelimage.getrzs: Could not find necessary parameter! Exiting..."
        sys.exit(1)
    imagehdu = pyfits.open(imagename)[0]
    imagedata = imagehdu.data
    imagewcs = pywcs.WCS(imagehdu.header)
    #centerxpix,centerypix = imagewcs.wcs_sky2pix(centerra_deg,centerdec_deg,1)
    centerxpix,centerypix = imagewcs.wcs_world2pix(centerra_deg,centerdec_deg,1)
    # centerxpix = centerxpix[0]
    # centerypix = centerypix[0]
    rpix = np.arange(imagedata.shape[1])-centerxpix
    zpix = np.arange(imagedata.shape[0])-centerypix
    xpixsize = np.sqrt(imagehdu.header['CD1_1']**2+imagehdu.header['CD1_2']**2)*3600.
    ypixsize = np.sqrt(imagehdu.header['CD2_1']**2+imagehdu.header['CD2_2']**2)*3600.
    rasec = rpix*xpixsize
    zasec = zpix*ypixsize
    rkpc = rasec*distmpc*1000./206265.
    zkpc = zasec*distmpc*1000./206265.
    Rkpc,Zkpc = np.meshgrid(rkpc,zkpc)
    
    return Rkpc.reshape(-1),Zkpc.reshape(-1),Rkpc.shape


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "Syntax: [Configuration file]"
        sys.exit(1)
