import numpy as np
import math
import os
import sys
import galfit_modelclass as modelclass
from lmfit import Parameters
##################################################################
#This file contains functions for producing arrays of free parameters that are friendly to being used in the C++ portion of the fitting algorithm
#Modification History:
#Date                  User                Notes
#6/11/13              ASR                 Created
#9/11/13              ASR                 Added N for bulges
#10/16/13             ASR                 Added support for rings
##################################################################
#Goes through the parameter list, returns arrays containing information on the mapping between disk,bulge, and truncation components and the parameter list. This is a little spaghetti-codey, but it'll do for now.
def convertparams(params):
    keys = params.keys()

    allnames = []
    bulgenames = []
    disknames = []
    ringnames = []
    disktruncations = []
    inclinationparam = ''
    roffsetparam = None
    zoffsetparam = None
    for key in keys:
        allnames.append(params[key].compid['name'])
        if params[key].compid['component'] == 'r_offset':
            roffsetparam = key
        if params[key].compid['component'] == 'z_offset':
            zoffsetparam = key
        if params[key].compid['component'] == 'inclination':
            inclinationparam = key
        if params[key].compid['component'] == 'bulge':
            bulgenames.append(params[key].compid['name'])
        if params[key].compid['component'] == 'disk':
            if params[key].compid['paramtype'] == 'hr':
                if 'innertrunc' in params[key].compid.keys() and 'outertrunc' in params[key].compid.keys():
                    disknames.append(params[key].compid['name'])
                    disktruncations.append((params[key].compid['innertrunc'],params[key].compid['outertrunc']))
                else:
                    print 'Error! each disk hr parameter entry must have truncation information! Exiting...'
                    sys.exit(1)
        if params[key].compid['component'] == 'ring':
            if params[key].compid['paramtype'] == 'rzero':
                if 'innertrunc' in params[key].compid.keys() and 'outertrunc' in params[key].compid.keys():
                    ringnames.append(params[key].compid['name'])
                    #disktruncations.append((params[key].compid['innertrunc'],params[key].compid['outertrunc']))
                    print "NOTE: Ring truncations not implemented yet (if ever)"
                else:
                    print 'Error! each ring rzero parameter entry must have truncation information! Exiting...'
                    sys.exit(1)


    uniquebulgenames = np.unique(np.array(bulgenames))
    uniqueringnames = np.unique(np.array(ringnames))
    uniquedisktruncations = list(set(disktruncations))
    # print "Debug: ",disknames
    # print "Debug: ",uniquedisktruncations
    # print "Debug: ",disktruncations
    numdiskspertruncation = np.zeros(len(uniquedisktruncations))
    # print "Debug: ",numdiskspertruncation
    hrlist = []
    hzlist = []
    diskmuzerolist = []
    #Getting the disk parameter names:
    for i in range(len(uniquedisktruncations)):
        #Get all disks that have this truncation:
        tempdisknames = [disknames[j] for j in range(len(disktruncations)) if disktruncations[j] == uniquedisktruncations[i]]
        # print "Debug: ",uniquedisktruncations[i],tempdisknames
        #For each disk, add its parameter names to the appropriate lists:
        for j in range(len(tempdisknames)):
            diskinfo = [(params[keys[k]].compid['paramtype'],keys[k]) for k in range(len(keys)) if allnames[k] == tempdisknames[j]]
            for k in range(len(diskinfo)):
                if diskinfo[k][0] == 'hz':
                    hzlist.append(diskinfo[k][1])
                elif diskinfo[k][0] == 'hr':
                    hrlist.append(diskinfo[k][1])
                else:#must be muzero:
                    diskmuzerolist.append(diskinfo[k][1])
        numdiskspertruncation[i] = len(tempdisknames)

    #Getting the truncation parameter names:
    innertrunclist = []
    outertrunclist = []
    for i in range(len(uniquedisktruncations)):
        innerparam = [None]
        if uniquedisktruncations[i][0] != None:
            innerparam = [keys[k] for k in range(len(keys)) if allnames[k] == uniquedisktruncations[i][0]]
        outerparam = [None]
        if uniquedisktruncations[i][1] != None:
            outerparam = [keys[k] for k in range(len(keys)) if allnames[k] == uniquedisktruncations[i][1]]
        innertrunclist.append(innerparam[0])
        outertrunclist.append(outerparam[0])

    #Getting the bulge parameter names:
    relist = []
    ablist = []
    nlist = []
    bulgemuzerolist = []
    for i in range(len(uniquebulgenames)):
        bulgeinfo = [(params[keys[j]].compid['paramtype'],keys[j]) for j in range(len(keys)) if allnames[j] == uniquebulgenames]
        for j in range(len(bulgeinfo)):
            if bulgeinfo[j][0] == 're':
                relist.append(bulgeinfo[j][1])
            elif bulgeinfo[j][0] == 'ab':
                ablist.append(bulgeinfo[j][1])
            elif bulgeinfo[j][0] == 'N':
                nlist.append(bulgeinfo[j][1])
            else:#must be muzero:
                bulgemuzerolist.append(bulgeinfo[j][1])

    #Getting the ring parameter names:
    rzerolist = []
    sigzerolist = []
    ringhzlist = []
    ringmuzerolist = []
    for i in range(len(uniqueringnames)):
        ringinfo = [(params[keys[j]].compid['paramtype'],keys[j]) for j in range(len(keys)) if allnames[j] == uniqueringnames]
        for j in range(len(ringinfo)):
            if ringinfo[j][0] == 'rzero':
                rzerolist.append(ringinfo[j][1])
            elif ringinfo[j][0] == 'sigzero':
                sigzerolist.append(ringinfo[j][1])
            elif ringinfo[j][0] == 'hz':
                ringhzlist.append(ringinfo[j][1])
            else:#must be muzero:
                ringmuzerolist.append(ringinfo[j][1])

    return inclinationparam,hrlist,hzlist,diskmuzerolist,rzerolist,sigzerolist,ringhzlist,ringmuzerolist,relist,ablist,nlist,bulgemuzerolist,innertrunclist,outertrunclist,numdiskspertruncation,roffsetparam,zoffsetparam

if __name__ == "__main__":
    # if len(sys.argv) != 2:
    #     print "Syntax: [Configuration file]"
    #     sys.exit(1)
    pass
