import numpy as np
import math
import os
import sys
import astropy.io.fits as pyfits
import astropy.wcs as pywcs
import galfit_modelclass as modelclass
import ConfigParser
##################################################################
#This file contains functions for reading in an input file and setting up a model
#Modification History:
#Date                  User                Notes
#6/7/13               ASR                 Created
#6/10/13              ASR                 Wrote process_cfg_param and readcfg
#6/11/13              ASR                 Wrote loadimgs, finished readcfg
#9/11/13              ASR                 Added the ability to vary bulge N
#10/16/13             ASR                 Added support for rings
##################################################################
#Print out a numpy array to a fits file, overwriting if necessary:
def writefits(image,filename,header=None):
    hdu = pyfits.PrimaryHDU(data=image,header=header)
    if os.path.isfile(filename):
        os.remove(filename)
    hdu.writeto(filename)

#Reads a configuration file and makes an instance of the galaxy model class:
def readcfg(cfgfile):
    config = ConfigParser.ConfigParser()
    config.read(cfgfile)
    try:
        #Get the basics to set up the model:
        ival,ivary,imin,imax = get_lm_param(config,'inclination',float)
        distmpc = process_cfg_param(config,'constants','distance',float,False)
        seeing = process_cfg_param(config,'constants','seeing',float,False)
        samplerate = process_cfg_param(config,'constants','samplerate',int,False)
        boundskpc = process_cfg_param(config,'constants','bounds',float,False)
        galaxymodel = modelclass.galaxy(distmpc,ival,seeing,samplerate,boundskpc,imin,imax,ivary)

        #output names:
        if config.has_section('outputs'):
            galaxymodel.outfullimagename = process_cfg_param(config,'outputs','outfullimage',str,True)
            galaxymodel.outfullfitparamsname = process_cfg_param(config,'outputs','outfullfitparams',str,True)
            galaxymodel.outfullbootparamsname = process_cfg_param(config,'outputs','outfullbootparams',str,True)
            

        #A list of all component names to ensure that they all have unique identifiers:
        componentnames = []
        usedtruncnames = []
        alltruncnames = []

        #Add r and z offsets:
        if config.has_section('r_offset'):
            rval,rvary,rmin,rmax = get_lm_param(config,'r_offset',float)
            info = {'component':'r_offset','name':'r_offset','paramtype':'r_offset'}
            galaxymodel.add_param(rmin,rmax,rvary,rval,info)
        else:
            print "Warning: No 'r_offset' section. Assuming that there are zero radial offsets..."
            rval = 0.
            rvary = False
            rmin = 0.
            rmax = 0.
            info = {'component':'r_offset','name':'r_offset','paramtype':'r_offset'}
            galaxymodel.add_param(rmin,rmax,rvary,rval,info)
        if config.has_section('z_offset'):
            zval,zvary,zmin,zmax = get_lm_param(config,'z_offset',float)
            info = {'component':'z_offset','name':'z_offset','paramtype':'z_offset'}
            galaxymodel.add_param(zmin,zmax,zvary,zval,info)
        else:
            print "Warning: No 'r_offset' section. Assuming that there are zero radial offsets..."
            zval = 0.
            zvary = False
            zmin = 0.
            zmax = 0.
            info = {'component':'z_offset','name':'z_offset','paramtype':'z_offset'}
            galaxymodel.add_param(zmin,zmax,zvary,zval,info)


        #Add all the disks:
        try:
            disklist = process_cfg_param(config,'disks','disklist',list,True)
            #If there are no disks or no disklist parameter, display a warning message but continue
        except ConfigParser.NoSectionError:
            print "Warning: No 'disks' section. Assuming a system with zero disks..."
        except ConfigParser.NoOptionError:
            print "Warning: No 'disklist' parameter in 'disks' section. Assuming a system with zero disks..."
        else:
            #load in the disks:
            for disk in disklist:
                componentnames.append(disk)
                muval,muvary,mumin,mumax = get_lm_param(config,disk,float,'muzero_')
                hrval,hrvary,hrmin,hrmax = get_lm_param(config,disk,float,'hr_')
                hzval,hzvary,hzmin,hzmax = get_lm_param(config,disk,float,'hz_')
                innertrunc = process_cfg_param(config,disk,'innertrunc',str,True)
                outertrunc = process_cfg_param(config,disk,'outertrunc',str,True)
                if innertrunc != None:
                    usedtruncnames.append(innertrunc)
                if outertrunc != None:
                    usedtruncnames.append(outertrunc)
                galaxymodel.add_disk(disk,mumin,mumax,muval,muvary,hrmin,hrmax,hrval,hrvary,hzmin,hzmax,hzval,hzvary,innertrunc,outertrunc)

        #Add all the rings:
        try:
            ringlist = process_cfg_param(config,'rings','ringlist',list,True)
            #If there are no disks or no disklist parameter, display a warning message but continue
        except ConfigParser.NoSectionError:
            print "Warning: No 'rings' section. Assuming a system with zero rings..."
        except ConfigParser.NoOptionError:
            print "Warning: No 'ringlist' parameter in 'disks' section. Assuming a system with zero rings..."
        else:
            #load in the disks:
            for ring in ringlist:
                componentnames.append(ring)
                muval,muvary,mumin,mumax = get_lm_param(config,ring,float,'muzero_')
                rzeroval,rzerovary,rzeromin,rzeromax = get_lm_param(config,ring,float,'rzero_')
                sigzeroval,sigzerovary,sigzeromin,sigzeromax = get_lm_param(config,ring,float,'sigzero_')
                hzval,hzvary,hzmin,hzmax = get_lm_param(config,ring,float,'hz_')
                innertrunc = process_cfg_param(config,ring,'innertrunc',str,True)
                outertrunc = process_cfg_param(config,ring,'outertrunc',str,True)
                if innertrunc != None:
                    usedtruncnames.append(innertrunc)
                if outertrunc != None:
                    usedtruncnames.append(outertrunc)
                galaxymodel.add_ring(ring,mumin,mumax,muval,muvary,rzeromin,rzeromax,rzeroval,rzerovary,sigzeromin,sigzeromax,sigzeroval,sigzerovary,hzmin,hzmax,hzval,hzvary,innertrunc,outertrunc)
                

        #Add all the bulges:
        try:
            bulgelist = process_cfg_param(config,'bulges','bulgelist',list,True)
            #If there are no bulges or no bulgelist parameter, display a warning message but continue
        except ConfigParser.NoSectionError:
            print "Warning: No 'bulges' section. Assuming a system with zero bulges..."
        except ConfigParser.NoOptionError:
            print "Warning: No 'bulgelist' parameter in 'bulges' section. Assuming a system with zero bulges..."
        else:
            #load in the disks:
            for bulge in bulgelist:
                componentnames.append(bulge)
                muval,muvary,mumin,mumax = get_lm_param(config,bulge,float,'muzero_')
                reval,revary,remin,remax = get_lm_param(config,bulge,float,'re_')
                abval,abvary,abmin,abmax = get_lm_param(config,bulge,float,'ab_')
                nval,nvary,nmin,nmax = get_lm_param(config,bulge,float,'n_')
                galaxymodel.add_bulge(bulge,mumin,mumax,muval,muvary,remin,remax,reval,revary,abmin,abmax,abval,abvary,nmin,nmax,nval,nvary)
                
        #Add all the truncations:
        try:
            trunclist = process_cfg_param(config,'truncations','truncationlist',list,True)
            #If there are no truncations or no truncationlist parameter, display a warning message but continue
        except ConfigParser.NoSectionError:
            print "Warning: No 'truncations' section. Assuming a system with zero truncations..."
        except ConfigParser.NoOptionError:
            print "Warning: No 'truncationlist' parameter in 'truncations' section. Assuming a system with zero truncations..."
        else:
            for trunc in trunclist:
                componentnames.append(trunc)
                alltruncnames.append(trunc)
                val,vary,tmin,tmax = get_lm_param(config,trunc,float)
                galaxymodel.add_truncation(trunc,tmin,tmax,val,vary)

        #If any of the truncations used in the disks are not real, exit:
        if not set(usedtruncnames).issubset(alltruncnames):
            print "Error: A named disk truncation does not have its fitting parameters listed! Exiting..."
            sys.exit(1)

        #If the component names are not unique, exit:
        if len(componentnames) != len(np.unique(componentnames)):
            print "Error: All component names (those in disklist, bulgelist, and truncationlist) must be unique! Exiting..."
            sys.exit(1)




        #Get info about the data and about the limitations to enforce on it in the fit:
        image = errimage = fluxunits = centerra_deg = centerdec_deg = zp_keyword = maskimage = coveragexpix = coverageypix = None
        rkpc = zkpc = imageflux = errorflux = coveragemap = None
        if config.has_section('data'):
            image = process_cfg_param(config,'data','image',str,False)
            errimage = process_cfg_param(config,'data','error_image',str,True)
            maskimage = process_cfg_param(config,'data','mask_image',str,True)
            fluxunits = process_cfg_param(config,'data','flux_units',bool,False)
            centerra_deg = process_cfg_param(config,'data','center_RA',float,False)
            centerdec_deg = process_cfg_param(config,'data','center_Dec',float,False)
            zp_keyword = process_cfg_param(config,'data','zp_keyword',str,True)
            max_err = process_cfg_param(config,'constraints','max_error',float,True)
            min_fluxerr = process_cfg_param(config,'constraints','min_fluxerr',float,True)
            rkpc,zkpc,imageflux,errorflux,coveragemap,coveragexpix,coverageypix = loadimgs(image,errimage,maskimage,centerra_deg,centerdec_deg,distmpc,max_err,min_fluxerr,fluxunits,zp_keyword)
            return galaxymodel,rkpc,zkpc,imageflux,errorflux,coveragemap,coveragexpix,coverageypix
        else:
            return galaxymodel

    except Exception as excep:
        if len(excep.args) == 3:
            print "Error reading parameter '{0:s}' from section '{1:s}': {2:s}".format(excep.args[0],excep.args[1],excep.args[2])
        elif len(excep.args) == 1:
            print "Error in setupmodel! {0:s}".format(excep.args[0])
        sys.exit(1)

   
#Reads the data (and errors) in, and computes the relative positions in kpc of each pixel. Finally, returns 1D arrays of R,z,flux for all pixels with small enough errors.
def loadimgs(imagename,errimagename,maskimagename,centerra,centerdec,distmpc,maxerr,minfluxerr,fluxunits=True,zp_keyword=None):
    #Load the image:
    imagehdu = pyfits.open(imagename)[0]
    imagedata = imagehdu.data

    errimage = np.zeros(imagehdu.data.shape)
    if errimagename != None:
        errimage = pyfits.open(errimagename)[0].data

    if errimage.shape != imagedata.shape:
        print "Error: Image and error image must be exact same size! Exiting..."
        sys.exit(1)
    
    errmagimage = errimage
    rawerrimage = errimage.copy()
    if fluxunits:
        errmagimage = errmagimage*0+999
        errmagimage[imagedata != 0] = np.abs(1.086*errimage[imagedata != 0]/imagedata[imagedata != 0])

    # print imagename
    imagewcs = pywcs.WCS(imagehdu.header)
    centerxpix,centerypix = imagewcs.wcs_world2pix(centerra,centerdec,1)

    xpix = np.arange(imagedata.shape[1])
    ypix = np.arange(imagedata.shape[0])
    rpix = np.arange(imagedata.shape[1])-centerxpix
    zpix = np.arange(imagedata.shape[0])-centerypix
    xpixsize = np.sqrt(imagehdu.header['CD1_1']**2+imagehdu.header['CD1_2']**2)*3600.
    ypixsize = np.sqrt(imagehdu.header['CD2_1']**2+imagehdu.header['CD2_2']**2)*3600.
    rasec = rpix*xpixsize
    zasec = zpix*ypixsize
    rkpc = rasec*distmpc*1000./206265.
    zkpc = zasec*distmpc*1000./206265.
    Rindices,Zindices = np.meshgrid(np.arange(imagedata.shape[1]),np.arange(imagedata.shape[0]))
    Rkpc,Zkpc = np.meshgrid(rkpc,zkpc)
    Xpix,Ypix = np.meshgrid(xpix,ypix)

    #If the images are flux images, find the zeropoint and correct the flux values so that they will be mag arcsec^-2 when -2.5*log10()'d. 
    if fluxunits:
        magzp = 0
        if zp_keyword != None:
            magzp = imagehdu.header[zp_keyword]
        else:
            print "Warning: zp_keyword is none! Assuming the magnitude zeropoint is 0..."
        #print "Debug: ",np.average(imagedata),magzp,xpixsize,ypixsize
        imagedata = imagedata*10**(-magzp/2.5)/(xpixsize*ypixsize)
        errimage = errimage*10**(-magzp/2.5)/(xpixsize*ypixsize)
    else:
        imagedata = 10**(-imagedata/2.5)#Must convert into flux values for fitting
        errimage = imagedata*errmagimage/1.086

    onedrawerr = rawerrimage.reshape(-1)
    onederr = errimage.reshape(-1)
    onederrmag = errmagimage.reshape(-1)
    onedrkpc = Rkpc.reshape(-1)
    onedzkpc = Zkpc.reshape(-1)
    onedimage = imagedata.reshape(-1)
    onedxpix = Xpix.reshape(-1)
    onedypix = Ypix.reshape(-1)

    #Read in mask, if necessary:
    onedmask = np.ones(len(onedimage))
    if maskimagename != None:
        maskimagedata = pyfits.open(maskimagename)[0].data
        if maskimagedata.shape != imagedata.shape:
            print "Error: Mask image does not have the same shape as the data image! Exiting..."
            sys.exit(1)
        onedmask = maskimagedata.reshape(-1)

    cutbool = (onedmask > 0)
    if errimagename != None:
        if maxerr != None:
            cutbool = cutbool & (onederrmag < maxerr)
        if minfluxerr != None:
            cutbool = cutbool & (onedrawerr > minfluxerr)
    onederr = onederr[cutbool]
    onedrkpc = onedrkpc[cutbool]
    onedzkpc = onedzkpc[cutbool]
    onedimage = onedimage[cutbool]
    onedxpix = onedxpix[cutbool]
    onedypix = onedypix[cutbool]
        
    # print "Debug:",np.sum(cutbool)

    coveragemap = np.zeros(imagedata.shape)
    coveragemap[onedypix,onedxpix] = 1.
         
    return onedrkpc,onedzkpc,onedimage,onederr,coveragemap,onedxpix,onedypix#Flux image and errors

#Gets the 4 necessary components of a LM parameter: value, vary, min, and max. All can be none except for vary, and value cannot be none if vary is false.
def get_lm_param(config,section,vartype,prefix=""):
    #Get the 4 parameters:
    value = process_cfg_param(config,section,'{0:s}value'.format(prefix),vartype,True)
    vary = process_cfg_param(config,section,'{0:s}vary'.format(prefix),bool,False)
    valmin = process_cfg_param(config,section,'{0:s}min'.format(prefix),vartype,True)
    valmax = process_cfg_param(config,section,'{0:s}max'.format(prefix),vartype,True)
    if valmin > valmax:
        print "Warning: {0:s}.{1:s} has min value larger than max value! Flipping them...".format(section,prefix)
        temp = valmin*1.
        valmin = valmax*1.
        valmax = temp
    if not vary and value == None:
        raise Exception('value',section,'Cannot have a null value if the parameter is fixed.')
    return value,vary,valmin,valmax

#Processes an individual configuration parameter:
def process_cfg_param(config,section,parametername,vartype,canbenull=False):
    if canbenull:
        paramval = config.get(section,parametername)
        if paramval.lower() == 'none':
            return None
    paramval = None
    if vartype == int:
        paramval = config.getint(section,parametername)
    elif vartype == float:
        paramval = config.getfloat(section,parametername)
    elif vartype == bool:
        paramval = config.getboolean(section,parametername)
    else:
        paramval = config.get(section,parametername)
        if vartype == list:
            paramval = paramval.split(",")
    return paramval

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print "Syntax: [Configuration file]"
        sys.exit(1)
