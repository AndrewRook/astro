import numpy as np
import math
import os
from lmfit import Parameters
##################################################################
#This file contains the class that sets up and holds the parameter list of galaxy features that will be modeled.
#Modification History:
#Date                  User                Notes
#5/17/13               ASR                 Created
#5/20/13               ASR                 Decided that incl would be fixed -> v-1
#5/21/13               ASR                 Decided that galaxy fitting would be done elsewhere -> v-2
#6/6/13                ASR                 Copied to galfit_modelclass.py in joint_progs directory, added back in the ability to vary inclination since the new integration code doesn't use that as a shortcut.
#9/11/13               ASR                 Added the ability to vary N for bulges
#10/16/13             ASR                 Added support for rings
##################################################################

#The class that holds the information about the galaxy model, i.e. the number and geometry of the disks, whether there's a truncation and what other components it affects, etc. 
class galaxy:
    def __init__(self,distmpc,inclination,seeingasec,samplerate=10,int_limkpc=30,minincl=0.,maxincl=90.,varyincl=False):
        self.disklist = []
        self.bulgelist = []
        self.ringlist = []
        self.barlist = []
        self.truncationlist = []
        self.params = Parameters()
        inclinationinfo = {'component':'inclination','name':'inclination','paramtype':'inclination'}
        self.add_param(minincl,maxincl,varyincl,inclination,inclinationinfo)
        self.seeingsample = samplerate
        self.seeingasec = seeingasec
        self.distmpc = distmpc
        self.int_limkpc = int_limkpc#For discrete integration
        self.outfullimagename = None
        self.outfullfitparamsname = None
        self.outfullbootparamsname = None

    def add_disk(self,diskname,muzeromin=None,muzeromax=None,muzerovalue=None,muzerovary=True,hrmin=0.0,hrmax=None,hrvalue=None,hrvary=True,hzmin=0.0,hzmax=None,hzvalue=None,hzvary=True,innertrunc=None,outertrunc=None):

        if (muzerovalue == None and muzerovary == False) or (hrvalue == None and hrvary == False) or (hzvalue == None and hzvary == False):
            print "galaxy.add_disk: Error! If a disk component is fixed a value must be provided! Exiting..."
            sys.exit(1)

        hrinfo = {'component':'disk','name':diskname,'paramtype':'hr','innertrunc':innertrunc,'outertrunc':outertrunc}
        hzinfo = {'component':'disk','name':diskname,'paramtype':'hz'}
        muzeroinfo = {'component':'disk','name':diskname,'paramtype':'muzero'}
        self.add_param(muzeromin,muzeromax,muzerovary,muzerovalue,muzeroinfo)
        self.add_param(hrmin,hrmax,hrvary,hrvalue,hrinfo)
        self.add_param(hzmin,hzmax,hzvary,hzvalue,hzinfo)

    def add_ring(self,ringname,muzeromin=None,muzeromax=None,muzerovalue=None,muzerovary=True,rzeromin=0.0,rzeromax=None,rzerovalue=None,rzerovary=True,sigzeromin=0.0,sigzeromax=None,sigzerovalue=None,sigzerovary=True,hzmin=0.0,hzmax=None,hzvalue=None,hzvary=True,innertrunc=None,outertrunc=None):

        if (muzerovalue == None and muzerovary == False) or (rzerovalue == None and rzerovary == False) or (sigzerovalue == None and sigzerovary == False) or (hzvalue == None and hzvary == False):
            print "galaxy.add_ring: Error! If a ring component is fixed a value must be provided! Exiting..."
            sys.exit(1)

        rzeroinfo = {'component':'ring','name':ringname,'paramtype':'rzero','innertrunc':innertrunc,'outertrunc':outertrunc}
        sigzeroinfo = {'component':'ring','name':ringname,'paramtype':'sigzero'}
        hzinfo = {'component':'ring','name':ringname,'paramtype':'hz'}
        muzeroinfo = {'component':'ring','name':ringname,'paramtype':'muzero'}
        self.add_param(muzeromin,muzeromax,muzerovary,muzerovalue,muzeroinfo)
        self.add_param(rzeromin,rzeromax,rzerovary,rzerovalue,rzeroinfo)
        self.add_param(sigzeromin,sigzeromax,sigzerovary,sigzerovalue,sigzeroinfo)
        self.add_param(hzmin,hzmax,hzvary,hzvalue,hzinfo)

    def add_bulge(self,bulgename,muzeromin=None,muzeromax=None,muzerovalue=None,muzerovary=True,remin=0.0,remax=None,revalue=None,revary=True,abmin=0.0,abmax=None,abvalue=None,abvary=True,nmin=0.0,nmax=None,nvalue=None,nvary=True,innertrunc=None,outertrunc=None,):

        if (muzerovalue == None and muzerovary == False) or (revalue == None and revary == False) or (abvalue == None and abvary == False) or (nvalue == None and nvary == False):
            print "galaxy.add_bulge: Error! If a bulge component is fixed a value must be provided! Exiting..."
            sys.exit(1)

        reinfo = {'component':'bulge','name':bulgename,'paramtype':'re','innertrunc':innertrunc,'outertrunc':outertrunc}
        abinfo = {'component':'bulge','name':bulgename,'paramtype':'ab'}
        ninfo = {'component':'bulge','name':bulgename,'paramtype':'N'}
        muzeroinfo = {'component':'bulge','name':bulgename,'paramtype':'muzero'}
        self.add_param(muzeromin,muzeromax,muzerovary,muzerovalue,muzeroinfo)
        self.add_param(remin,remax,revary,revalue,reinfo)
        self.add_param(abmin,abmax,abvary,abvalue,abinfo)
        self.add_param(nmin,nmax,nvary,nvalue,ninfo)

    def add_truncation(self,truncationname,rmin=0.0,rmax=None,rvalue=None,rvary=True):

        if rvalue == None and rvary == False:
            print "galaxy.add_truncaton: Error! If a truncation component is fixed a value must be provided! Exiting..."
            sys.exit(1)

        rinfo = {'component':'truncation','name':truncationname,'paramtype':'r'}
        self.add_param(rmin,rmax,rvary,rvalue,rinfo)

    def add_param(self,minval,maxval,varyval,value,info):
        paramname = "parameter_{0:d}".format(len(self.params)+1)
        self.params.add(paramname,vary=varyval)
        if minval != None:
            self.params[paramname].min = minval
        if maxval != None:
            self.params[paramname].max = maxval
        if value != None:
            self.params[paramname].value = value
        self.params[paramname].compid = info
        
    def randomize_free_params(self):
        for paramkey in self.params.keys():
            if self.params[paramkey].vary == True:
                lowlim = -3e9#This is arbitrary, but seems reasonable. In most cases the bounds will be specified anyway.
                highlim = 3e9
                if self.params[paramkey].min != None:
                    lowlim = self.params[paramkey].min
                if self.params[paramkey].max != None:
                    highlim = self.params[paramkey].max
                self.params[paramkey].value = (np.random.uniform(lowlim,highlim,1))[0]
                #print self.params[paramkey].compid,self.params[paramkey].value,self.params[paramkey].min,self.params[paramkey].max

    def get_num_free_params(self):
        numfree = 0
        for paramkey in self.params.keys():
            if self.params[paramkey].vary == True:
                numfree += 1

        return numfree

if __name__ == "__main__":
    ngc891 = galaxy(9.5,90.,0.9)
    ngc891.add_truncation('trunc1',rmin=2,rmax=4,rvary=True)
    ngc891.add_bulge('bulge1',muzeromin=25,muzeromax=8,remin=0.1,remax=2,abvary=False,abvalue=1.)
    ngc891.add_disk('disk1',muzeromin=19,muzeromax=12,hrmin=0.1,hrmax=10,hzmin=0.01,hzmax=2)
    ngc891.randomize_free_params()

    rkpc = np.linspace(-10,10,501)
    zkpc = np.linspace(-2.5,2.5,126)

    Rkpc,Zkpc = np.meshgrid(rkpc,zkpc)

    print len(ngc891.params)
    print ngc891.params[0]
    # print ngc891.params['parameter_1'],ngc891.params['parameter_1'].compid
