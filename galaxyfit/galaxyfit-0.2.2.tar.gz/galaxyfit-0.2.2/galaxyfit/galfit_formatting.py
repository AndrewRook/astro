import numpy as np
import math
import os
from lmfit import Parameters,minimize
##################################################################
#This file contains functions related to printing formatted output of parameter lists:
#Modification History:
#Date                  User                Notes
#6/17/13               ASR                 Created
#10/16/13             ASR                 Added support for rings
##################################################################

#Print a parameter. If fileobj is specified, write to the file:
def printparam(param,name,unit=None,format = 'f', precision=2,error_precision=None,prepend_spacenum=0,fileobj=None):
    paramval = param.value
    paramvary = param.vary
    parammin = param.min
    parammax = param.max


    if error_precision == None:
        error_precision = precision+1

    outstring = " "*prepend_spacenum+name
    if format == 'f' or format == 'e':
        outstring = outstring+" = {0:.{1:d}{2:s}}".format(paramval,precision,format)
    # elif format == 'd':
    #     outstring = outstring+" = {0:{1:s}}".format(int(paramval),format)
    else:
        print "Format code '{0:s}' not recognized! Exiting...".format(format)
        sys.exit(1)
        
    if unit != None:
        outstring = outstring + " "+unit
    if paramvary == False:
        outstring = outstring + " (FIXED)"
    else:
        outstring = outstring + " ({0:.{1:d}{2:s}}<{3:s}<{4:.{1:d}{2:s}})".format(parammin,precision,format,name,parammax)

    if fileobj != None:
        fileobj.write(outstring+"\n")
    else:
        print outstring

#Prints a formatted description of a model to the screen:
def print_modeltoscreen(params,supportdict,minobj=None):
    inclinationparam = supportdict['inclinationparam']
    hrlist = supportdict['hrlist']
    hzlist = supportdict['hzlist']
    diskmuzerolist = supportdict['diskmuzerolist']
    rzerolist = supportdict['rzerolist']
    sigzerolist = supportdict['sigzerolist']
    ringhzlist = supportdict['ringhzlist']
    ringmuzerolist = supportdict['ringmuzerolist']
    relist = supportdict['relist']
    ablist = supportdict['ablist']
    nlist = supportdict['nlist']
    bulgemuzerolist = supportdict['bulgemuzerolist']
    innertrunclist = supportdict['innertrunclist']
    outertrunclist = supportdict['outertrunclist']
    numdiskpertrunc = supportdict['numdiskspertruncation']
    trunclist = supportdict['innertrunclist']
    trunclist.extend(supportdict['outertrunclist'])
    trunclist = np.unique(np.array(trunclist))
    trunclist = trunclist[np.not_equal(trunclist,None)]
    roffsetparam = supportdict['roffsetparam']
    zoffsetparam = supportdict['zoffsetparam']

    diskcount = 0
    truncationindex = 0
    print "*"*20+"Disks"+"*"*20
    if len(hrlist) == 0:
        print "No Disks in Model"
    else:
        #Putting the disks in alphabetical order, then listing:
        disknames = np.array([params[hrlist[i]].compid['name'] for i in range(len(hrlist))])
        indices = np.argsort(disknames)
        for i in indices:
            print params[hrlist[i]].compid['name']
            printparam(params[diskmuzerolist[i]],'mu_zero',unit='mag arcsec^-2',format='f',precision=2,prepend_spacenum=5)
            printparam(params[hrlist[i]],'hr',unit = 'kpc',format='f',precision=2,prepend_spacenum=5)
            printparam(params[hzlist[i]],'hz',unit = 'kpc',format='f',precision=2,prepend_spacenum=5)
            innertruncname = 'None'
            outertruncname = 'None'
            if innertrunclist[truncationindex] != None:
                innertruncname = params[innertrunclist[truncationindex]].compid['name']
            if outertrunclist[truncationindex] != None:
                outertruncname = params[outertrunclist[truncationindex]].compid['name']
            print " "*5+"Inner Truncation = {0:s}".format(innertruncname)
            print " "*5+"Outer Truncation = {0:s}".format(outertruncname)
            diskcount += 1
            if diskcount >= numdiskpertrunc[truncationindex]:
                diskcount = 0
                truncationindex += 1
            
    # print "*"*45

    print "*"*20+"Bulges"+"*"*19
    if len(relist) == 0:
        print "No Bulges in Model"
    else:
        #Putting the rings in alphabetical order, then listing:
        ringnames = np.array([params[rzerolist[i]].compid['name'] for i in range(len(rzerolist))])
        indices = np.argsort(ringnames)
        for i in indices:
            print params[rzerolist[i]].compid['name']
            printparam(params[ringmuzerolist[i]],'mu_zero',unit='mag arcsec^-2',format='f',precision=2,prepend_spacenum=5)
            printparam(params[rzerolist[i]],'rzero',unit = 'kpc',format='f',precision=2,prepend_spacenum=5)
            printparam(params[sigzerolist[i]],'sigzero',format='f',precision=2,prepend_spacenum=5)
            printparam(params[ringhzlist[i]],'hz',format='f',precision=2,prepend_spacenum=5)

    print "*"*20+"Rings"+"*"*20
    if len(rzerolist) == 0:
        print "No Rings in Model"
    else:
        #Putting the bulges in alphabetical order, then listing:
        bulgenames = np.array([params[relist[i]].compid['name'] for i in range(len(relist))])
        indices = np.argsort(bulgenames)
        for i in indices:
            print params[relist[i]].compid['name']
            printparam(params[bulgemuzerolist[i]],'mu_zero',unit='mag arcsec^-2',format='f',precision=2,prepend_spacenum=5)
            printparam(params[relist[i]],'re',unit = 'kpc',format='f',precision=2,prepend_spacenum=5)
            printparam(params[ablist[i]],'a/b',format='f',precision=2,prepend_spacenum=5)
            printparam(params[nlist[i]],'N',format='f',precision=2,prepend_spacenum=5)
        
    print "*"*20+"Truncations"+"*"*14
    if len(trunclist) == 0:
        print "No Truncations in Model"
    else:
        #Putting the truncations in alphabetical order, then listing:
        truncnames = np.array([params[trunclist[i]].compid['name'] for i in range(len(trunclist))])
        indices = np.argsort(truncnames)
        for i in indices:
            print params[trunclist[i]].compid['name']
            printparam(params[trunclist[i]],'R_trunc',unit='kpc',format='f',precision=2,prepend_spacenum=5)
    
    print "*"*20+"Other"+"*"*20
    printparam(params[inclinationparam],'inclination',unit = 'degrees',format='f',precision=1)
    if roffsetparam != None:
        printparam(params[roffsetparam],'R_offset',unit='kpc',format='f',precision=2)
    if zoffsetparam != None:
        printparam(params[zoffsetparam],'z_offset',unit='kpc',format='f',precision=2)

    print "*"*45
    # printparam(params[inclinationparam],'inclination',unit = 'degrees',format='f',precision=1)
    # printparam(params[hrlist[0]],'hr',unit = 'kpc',format='f',precision=2)


def printfileline(fhandle,params,supportdict,pofp = True,chisquare=None):#pofp = print only free params
    inclinationparam = supportdict['inclinationparam']
    hrlist = supportdict['hrlist']
    hzlist = supportdict['hzlist']
    diskmuzerolist = supportdict['diskmuzerolist']
    rzerolist = supportdict['rzerolist']
    sigzerolist = supportdict['sigzerolist']
    ringhzlist = supportdict['ringhzlist']
    ringmuzerolist = supportdict['ringmuzerolist']
    relist = supportdict['relist']
    ablist = supportdict['ablist']
    nlist = supportdict['nlist']
    bulgemuzerolist = supportdict['bulgemuzerolist']
    # innertrunclist = supportdict['innertrunclist']
    # outertrunclist = supportdict['outertrunclist']
    # numdiskpertrunc = supportdict['numdiskspertruncation']
    trunclist = supportdict['innertrunclist']
    trunclist.extend(supportdict['outertrunclist'])
    trunclist = np.unique(np.array(trunclist))
    trunclist = trunclist[np.not_equal(trunclist,None)]
    roffsetparam = supportdict['roffsetparam']
    zoffsetparam = supportdict['zoffsetparam']
    
    if params[inclinationparam].vary or not pofp:
        fhandle.write("{0:6.3f} ".format(params[inclinationparam].value))
    if params[roffsetparam].vary or not pofp:
        fhandle.write("{0:6.3f} ".format(params[roffsetparam].value))
    if params[zoffsetparam].vary or not pofp:
        fhandle.write("{0:6.3f} ".format(params[zoffsetparam].value))
    for muzero in diskmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[muzero].value))
    for hr in hrlist:
        if params[hr].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[hr].value))
    for hz in hzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[hz].value))
    for muzero in bulgemuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[muzero].value))
    for re in relist:
        if params[re].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[re].value))
    for ab in ablist:
        if params[ab].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[ab].value))
    for n in nlist:
        if params[n].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[n].value))
    for muzero in ringmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:6.3f} '.format(params[muzero].value))
    for rzero in rzerolist:
        if params[rzero].vary or not pofp:
            fhandle.write('{0:6.3f} '.format(params[rzero].value))
    for sigzero in sigzerolist:
        if params[sigzero].vary or not pofp:
            fhandle.write('{0:6.3f} '.format(params[sigzero].value))
    for hz in ringhzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[hz].value))
    for trunc in trunclist:
        if params[trunc].vary or not pofp:
            fhandle.write("{0:6.3f} ".format(params[trunc].value))
    if chisquare != None:
        fhandle.write('{0:.6e}'.format(chisquare))
    fhandle.write("\n")

def printfileheader(fhandle,params,supportdict,pofp = True,chisquare=None):#pofp = print only free params
    inclinationparam = supportdict['inclinationparam']
    hrlist = supportdict['hrlist']
    hzlist = supportdict['hzlist']
    diskmuzerolist = supportdict['diskmuzerolist']
    rzerolist = supportdict['rzerolist']
    sigzerolist = supportdict['sigzerolist']
    ringhzlist = supportdict['ringhzlist']
    ringmuzerolist = supportdict['ringmuzerolist']
    relist = supportdict['relist']
    ablist = supportdict['ablist']
    nlist = supportdict['nlist']
    bulgemuzerolist = supportdict['bulgemuzerolist']
    # innertrunclist = supportdict['innertrunclist']
    # outertrunclist = supportdict['outertrunclist']
    # numdiskpertrunc = supportdict['numdiskspertruncation']
    trunclist = supportdict['innertrunclist']
    trunclist.extend(supportdict['outertrunclist'])
    trunclist = np.unique(np.array(trunclist))
    trunclist = trunclist[np.not_equal(trunclist,None)]
    roffsetparam = supportdict['roffsetparam']
    zoffsetparam = supportdict['zoffsetparam']
    
    fhandle.write("# ")
    if params[inclinationparam].vary or not pofp:
        fhandle.write("{0:s} ".format('incl(deg)'))
    if params[roffsetparam].vary or not pofp:
        fhandle.write("{0:s} ".format('roff(kpc)'))
    if params[zoffsetparam].vary or not pofp:
        fhandle.write("{0:s} ".format('zoff(kpc)'))
    for muzero in diskmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s}_muzero(mag"^-2) '.format(params[muzero].compid['name']))
    for hr in hrlist:
        if params[hr].vary or not pofp:
            fhandle.write("{0:s}_hr(kpc) ".format(params[hr].compid['name']))
    for hz in hzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:s}_hz(kpc) ".format(params[hz].compid['name']))
    for muzero in bulgemuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s}_muzero(mag"^-2) '.format(params[muzero].compid['name']))
    for re in relist:
        if params[re].vary or not pofp:
            fhandle.write("{0:s}_re(kpc) ".format(params[re].compid['name']))
    for ab in ablist:
        if params[ab].vary or not pofp:
            fhandle.write("{0:s}_ab ".format(params[ab].compid['name']))
    for n in nlist:
        if params[n].vary or not pofp:
            fhandle.write("{0:s}_n ".format(params[n].compid['name']))
    for muzero in ringmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s}_muzero(mag"^-2) '.format(params[muzero].compid['name']))
    for rzero in rzerolist:
        if params[rzero].vary or not pofp:
            fhandle.write('{0:s}_rzero(kpc) '.format(params[rzero].compid['name']))
    for sigzero in sigzerolist:
        if params[sigzero].vary or not pofp:
            fhandle.write('{0:s}_sigzero(kpc) '.format(params[sigzero].compid['name']))
    for hz in ringhzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:s}_hz(kpc) ".format(params[hz].compid['name']))
    for trunc in trunclist:
        if params[trunc].vary or not pofp:
            fhandle.write("{0:s}(kpc) ".format(params[trunc].compid['name']))
    if chisquare != None:
        fhandle.write('red_chi^2')
    fhandle.write("\n")

def printfileparamheader(fhandle,params,supportdict,pofp = True,chisquare=None):#pofp = print only free params
    inclinationparam = supportdict['inclinationparam']
    hrlist = supportdict['hrlist']
    hzlist = supportdict['hzlist']
    diskmuzerolist = supportdict['diskmuzerolist']
    rzerolist = supportdict['rzerolist']
    sigzerolist = supportdict['sigzerolist']
    ringhzlist = supportdict['ringhzlist']
    ringmuzerolist = supportdict['ringmuzerolist']
    relist = supportdict['relist']
    ablist = supportdict['ablist']
    nlist = supportdict['nlist']
    bulgemuzerolist = supportdict['bulgemuzerolist']
    trunclist = supportdict['innertrunclist']
    trunclist.extend(supportdict['outertrunclist'])
    trunclist = np.unique(np.array(trunclist))
    trunclist = trunclist[np.not_equal(trunclist,None)]
    roffsetparam = supportdict['roffsetparam']
    zoffsetparam = supportdict['zoffsetparam']
    
    fhandle.write("# ")
    if params[inclinationparam].vary or not pofp:
        fhandle.write("{0:s} ".format(inclinationparam))
    if params[roffsetparam].vary or not pofp:
        fhandle.write("{0:s} ".format(roffsetparam))
    if params[zoffsetparam].vary or not pofp:
        fhandle.write("{0:s} ".format(zoffsetparam))
    for muzero in diskmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s} '.format(muzero))
    for hr in hrlist:
        if params[hr].vary or not pofp:
            fhandle.write("{0:s} ".format(hr))
    for hz in hzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:s} ".format(hz))
    for muzero in bulgemuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s} '.format(muzero))
    for re in relist:
        if params[re].vary or not pofp:
            fhandle.write("{0:s} ".format(re))
    for ab in ablist:
        if params[ab].vary or not pofp:
            fhandle.write("{0:s} ".format(ab))
    for n in nlist:
        if params[n].vary or not pofp:
            fhandle.write("{0:s} ".format(n))
    for muzero in ringmuzerolist:
        if params[muzero].vary or not pofp:
            fhandle.write('{0:s} '.format(muzero))
    for rzero in rzerolist:
        if params[rzero].vary or not pofp:
            fhandle.write('{0:s} '.format(rzero))
    for sigzero in sigzerolist:
        if params[sigzero].vary or not pofp:
            fhandle.write('{0:s} '.format(sigzero))
    for hz in ringhzlist:
        if params[hz].vary or not pofp:
            fhandle.write("{0:s} ".format(hz))
    for trunc in trunclist:
        if params[trunc].vary or not pofp:
            fhandle.write("{0:s} ".format(trunc))
    if chisquare != None:
        fhandle.write('red_chi^2')
    fhandle.write("\n")


if __name__ == "__main__":
    pass
