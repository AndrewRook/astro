import numpy as np
import math
import os
from lmfit import Parameters,minimize
import ctypes
from ctypes import cdll
import galfit_formatting as formatting
import scipy.ndimage
import scipy.special
from scipy.interpolate import RectBivariateSpline
import tempfile
import astropy.io.fits as pyfits

libpath = os.path.split(os.path.realpath(__file__))[0]
galint = cdll.LoadLibrary('{0:s}/galaxyintegrate.so'.format(libpath))
##################################################################
#This file contains the function that does the actual LM fitting:
#Modification History:
#Date                  User                Notes
#6/12/13               ASR                 Created
#8/7/13               ASR                 Partial rewrite for cleanliness and accuracy
#10/16/13             ASR                 Added support for rings
##################################################################
#Print out a numpy array to a fits file, overwriting if necessary:
def writefits(image,filename,header=None):
    hdu = pyfits.PrimaryHDU(data=image,header=header)
    if os.path.isfile(filename):
        os.remove(filename)
    hdu.writeto(filename)

def fit(galaxyparams,galaxymodel,supportdict,justprintmodel=False):
    roffset = galaxyparams[supportdict['roffsetparam']].value
    zoffset = galaxyparams[supportdict['zoffsetparam']].value

    #Get hrs,hzs,etc:
    hrs = np.array([galaxyparams[paramname].value for paramname in supportdict['hrlist']])
    hzs = np.array([galaxyparams[paramname].value for paramname in supportdict['hzlist']])
    izero_disks = np.array([10**(-galaxyparams[paramname].value/2.5) for paramname in supportdict['diskmuzerolist']])
    izero_disks = izero_disks/(2*hrs)#to emissivity
    rzeros = np.array([galaxyparams[paramname].value for paramname in supportdict['rzerolist']])
    sigzeros = np.array([galaxyparams[paramname].value for paramname in supportdict['sigzerolist']])
    ringhzs = np.array([galaxyparams[paramname].value for paramname in supportdict['ringhzlist']])
    izero_rings = np.array([10**(-galaxyparams[paramname].value/2.5) for paramname in supportdict['ringmuzerolist']])
    izero_rings = izero_rings/(2*np.sqrt(2*math.pi*sigzeros**2))#Actually np.sqrt(2*math.pi)*sigzeros*(1 + scipy.special.erf(rzeros/(np.sqrt(2)*sigzeros)), but for version control purposes I will fix this error in post-processing
    res = np.array([galaxyparams[paramname].value for paramname in supportdict['relist']])
    ab = np.array([galaxyparams[paramname].value for paramname in supportdict['ablist']])
    n = np.array([galaxyparams[paramname].value for paramname in supportdict['nlist']])
    izero_bulges = np.array([10**(-galaxyparams[paramname].value/2.5) for paramname in supportdict['bulgemuzerolist']])
    innertruncs = np.array([galaxyparams[paramname].value if paramname is not None else 0 for paramname in supportdict['innertrunclist']])
    outertruncs = np.array([galaxyparams[paramname].value if paramname is not None else 2*galaxymodel.int_limkpc for paramname in supportdict['outertrunclist']])
    numdiskspertrunc = supportdict['numdiskspertruncation']

    #Getting other parameters:
    inclination = galaxyparams[supportdict['inclinationparam']].value
    #Offset r and z data values:
    rkpc = np.abs(supportdict['rkpc'] + roffset)
    zkpc = np.abs(supportdict['zkpc'] + zoffset)

    imageflux = None
    errorflux = None
    if not justprintmodel:
        imageflux = supportdict['imageflux']
        if 'errorflux' in supportdict.keys():
            if supportdict['errorflux'] != None:
                errorflux = supportdict['errorflux']

    kpctoasec = 1/(galaxymodel.distmpc*1000./206265.)
    seeingkpc = galaxymodel.seeingasec/kpctoasec
    seeingexcessmultiplier = 3.

    #Integrating the model:
    #print rkpc.min(),rkpc.max(),zkpc.min(),zkpc.max()
    rmin = rkpc.min()
    rmax = rkpc.max()
    zmin = zkpc.min()
    zmax = zkpc.max()
    rvals,zvals,modelimage,binsize = run_integration(rmin,rmax,zmin,zmax,izero_disks,hrs,hzs,izero_rings,rzeros,sigzeros,ringhzs,izero_bulges,res,ab,n,innertruncs,outertruncs,numdiskspertrunc,seeingkpc,galaxymodel.seeingsample,inclination,bound=galaxymodel.int_limkpc,seeingexcess=seeingexcessmultiplier,numcores=12,minresolution=0.)
    
    #Convolving the model with the seeing:
    convolved_modelimage = seeing_convolution(modelimage,seeingkpc/binsize)
    #print "Debug: convolution turned off!"

    #Getting the interpolated fluxes:
    #interpolated_modelfluxes = interpolategrid(rvals,zvals,modelimage,rkpc,zkpc)
    interpolated_modelfluxes = interpolategrid(rvals,zvals,convolved_modelimage,rkpc,zkpc)

    if justprintmodel:
        return interpolated_modelfluxes
    elif errorflux == None:
        return (interpolated_modelfluxes - imageflux)
    else:
        # np.savetxt('galfit_chisquare_debug.txt',zip(interpolated_modelfluxes,imageflux,errorflux))
        return (interpolated_modelfluxes - imageflux)/errorflux

#The wrapper for the fitting algorithm - with full step-by-step outputs for debugging:
def fit_woutputs(galaxyparams,galaxymodel,supportdict,coveragexpix,coverageypix,coveragemapshape,trackingfilename,justprintmodel=False):
    return np.ones(len(coveragexpix))

# #Wrapper to do a really simplistic galaxy fit:
# def simplefit(galaxyparams,galaxymodel,supportdict,coveragexpix,coverageypix,coveragemapshape,trackingfilename,justprintmodel=False):
#     return np.ones(len(coveragexpix))

def interpolategrid(rvals,zvals,image,rinterpvals,zinterpvals):
    spline = RectBivariateSpline(rvals,zvals,image,kx=1,ky=1)
    return spline.ev(rinterpvals,zinterpvals)

def seeing_convolution(image,seeing):
    return scipy.ndimage.gaussian_filter(image,seeing/2.355,order=0,mode='reflect')#2.335 is the conversion between FWHM and sigma for a normal distribution (See FWHM wikipedia page)

def run_integration(rmin,rmax,zmin,zmax,izero_disks,hrs,hzs,izero_rings,rzeros,sigzeros,ringhzs,izero_bulges,res,ab,n,innertruncrs,outertruncrs,numpertrunc,seeing,seeingsample,inclination,bound=50.,seeingexcess = 3.,numcores = 12,minresolution = 0.):
    binsize = seeing/seeingsample
    if seeing < minresolution:
        binsize = minresolution/seeingsample

    rvals = np.arange(rmin-seeing*seeingexcess,rmax+seeing*seeingexcess+binsize,binsize)
    zvals = np.arange(zmin-seeing*seeingexcess,zmax+seeing*seeingexcess+binsize,binsize)
    image = np.zeros((len(rvals),len(zvals)))

    bn = scipy.special.gammaincinv(2.*n,0.5)

    temp_data = ctypes.c_void_p(image.ctypes.data)
    temp_rvals = rvals.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_zvals = zvals.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_lenrvals = ctypes.c_int(len(rvals))
    temp_lenzvals = ctypes.c_int(len(zvals))
    temp_izero_disks = izero_disks.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_hrs = hrs.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_hzs = hzs.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_innertruncrs = innertruncrs.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_outertruncrs = outertruncrs.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_numpertrunc = npintarray_to_ctypearray(numpertrunc.astype(np.int))
    temp_lennumpertrunc = ctypes.c_int(len(numpertrunc))
    temp_izero_bulges = izero_bulges.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_res = res.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_ab = ab.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_n = n.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_bn = bn.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_lenizero_bulges = ctypes.c_int(len(izero_bulges))
    temp_inclination = ctypes.c_double(inclination)
    temp_bound = ctypes.c_double(bound)
    temp_numcores = ctypes.c_int(numcores)

    temp_izero_rings = izero_rings.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_rzeros = rzeros.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_sigzeros = sigzeros.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_ringhzs = ringhzs.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    temp_lenizero_rings = ctypes.c_int(len(izero_rings))

    galint.integrategalaxy(temp_data,temp_rvals,temp_zvals,temp_lenrvals,temp_lenzvals,temp_izero_disks,temp_hrs,temp_hzs,temp_innertruncrs,temp_outertruncrs,temp_numpertrunc,temp_lennumpertrunc,temp_izero_rings,temp_rzeros,temp_sigzeros,temp_ringhzs,temp_lenizero_rings,temp_izero_bulges,temp_res,temp_ab,temp_n,temp_bn,temp_lenizero_bulges,temp_inclination,temp_bound,temp_numcores)
    return rvals,zvals,image,binsize

def npintarray_to_ctypearray(inputarr):
    outarr = (ctypes.c_int*len(inputarr))()
    outarr[:] = inputarr
    return outarr

#From stack overflow:
def unique_file(file_name):
    dirname,filename = os.path.split(file_name)
    prefix,suffix = os.path.splitext(filename)
    fd,filename = tempfile.mkstemp(suffix,prefix+"_",dirname)
    return os.path.split(filename)[1]

if __name__ == "__main__":
    pass
